<?php
    include "folder_file.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lecture 6</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <form method="post">
            <input type="text" name="dir_name"> - 
            <button name="cr_dir">Create a Folder</button>
            <span class="erorr"><?=$error_fold?></span>  
            <br><br>
            <input type="text" name="f_name"> - <button>Create a File</button>
        </form>
    </header>
    <main>
        <table>
            <tr>
                <th>status</th>
                <th>size(bytes)</th>
                <th>name</th>
                <th>action</th>
            </tr>
        </table>
    </main>
</body>
</html>