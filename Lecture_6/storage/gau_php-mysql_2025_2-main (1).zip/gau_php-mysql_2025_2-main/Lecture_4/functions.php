<?php
    function f1(){
        echo "<h1>Hello PHP</h1>";
        echo "<h1>Hello Laravel</h1>";
    }

    function f2(){
        return "<h1>Hello PHP</h1>";
        echo "<h1>Hello Laravel</h1>";
    }

    function f3($a, $b, $c=9){
        echo $a+$b+$c;
    }

    f3(3, 4, 8);
?>