<?php
    $error_fold = "";

    if(isset($_POST['cr_dir'])){
        $folder = $_POST['dir_name'];
        if(!empty($folder)  &&  !is_dir("storage/".$folder)){
            mkdir("storage/".$folder);  
        }else{
           $error_fold = "Folder already exists or is empty"; 
        }
    }
?>