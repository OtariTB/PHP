<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Davaleba 1</title>
    <style>
        body{
            margin-left: 200px;
        }
    </style>
</head>
<body>
    <h3><a href="davaleba_1.php">Home</a></h3>
    <form action="datvla.php" method="get">
        <input type="text" name="saxel" placeholder="Saxeli">
        <br><br>
        <input type="text" name="gvar" placeholder="gvari">
        <br><br>
        <input type="text" name="xelfasi" placeholder="Xelfasi">
        <br><br>
        <input type="text" name="sashemosavlo" placeholder="%-Shi">
        <br><br>
        <button>Gamotvla</button>
    </form>
    <hr><hr>
   
</body>
</html>