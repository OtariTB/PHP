<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Davaleba 1</title>
    <style>
        body{
            margin-left: 200px;
        }
    </style>
</head>
<body>
    <h3><a href="davaleba_1.php">Home</a></h3>
    <table border="1">
        <tr>
            <th>სახელი</th>
            <th>გვარი</th>
            <th>ხელფასი</th>
            <th>საშემოსავლო</th>
            <th>ხელზე ასაღები</th>
        </tr>
        <tr>
            <th><?=$_GET['saxel']?></th>
            <th><?=$_GET['gvar']?></th>
            <th><?=$_GET['xelfasi']?></th>
            <th><?=$_GET['xelfasi']*$_GET['sashemosavlo']/100?></th>
            <th><?=$_GET['xelfasi']-$_GET['xelfasi']*$_GET['sashemosavlo']/100?></th>
        </tr>
    </table>
</body>
</html>