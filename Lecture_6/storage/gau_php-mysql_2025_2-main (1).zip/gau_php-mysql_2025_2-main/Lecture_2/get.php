<h1>GET Method</h1>
<?php
    echo "<pre>";
    print_r($_GET);
    echo "</pre>";
    echo "<div>".$_GET['email']."</div>";
    echo "<div>".$_GET['pass']."</div>";
?>