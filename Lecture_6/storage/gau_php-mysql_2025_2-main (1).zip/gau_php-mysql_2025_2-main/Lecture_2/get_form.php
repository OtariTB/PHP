<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GET</title>
    <style>
        .container{
            margin: auto;
            margin-left: 200px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="get.php" method="get">
            <input type="text" name="email" placeholder="Enter your email">
            <br><br>
            <input type="password" name="pass" placeholder="Enter your password">
            <br><br>
            <button>Signi In</button>
        </form>
    </div>
</body>
</html>