<?php
    $questions = [
        ['question'=>"What is HTML?", 'maxpoint'=>9],
        ['question'=>"What is CSS?", 'maxpoint'=>10],
        ['question'=>"What is JavaScript?", 'maxpoint'=>10],
        ['question'=>"What is C#?", 'maxpoint'=>10],
        ['question'=>"What is PHP?", 'maxpoint'=>10],
        ['question'=>"What is jQuery?", 'maxpoint'=>9],
    ];

    shuffle($questions);
?>